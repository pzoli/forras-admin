--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.accessibletype DROP CONSTRAINT accessibletype_pkey;
ALTER TABLE public.accessibletype ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.accessibletype_id_seq;
DROP TABLE public.accessibletype;
SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: accessibletype; Type: TABLE; Schema: public; Owner: pzoli
--

CREATE TABLE public.accessibletype (
    id integer NOT NULL,
    typename character varying(255)
);


ALTER TABLE public.accessibletype OWNER TO pzoli;

--
-- Name: accessibletype_id_seq; Type: SEQUENCE; Schema: public; Owner: pzoli
--

CREATE SEQUENCE public.accessibletype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accessibletype_id_seq OWNER TO pzoli;

--
-- Name: accessibletype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pzoli
--

ALTER SEQUENCE public.accessibletype_id_seq OWNED BY public.accessibletype.id;


--
-- Name: accessibletype id; Type: DEFAULT; Schema: public; Owner: pzoli
--

ALTER TABLE ONLY public.accessibletype ALTER COLUMN id SET DEFAULT nextval('public.accessibletype_id_seq'::regclass);


--
-- Data for Name: accessibletype; Type: TABLE DATA; Schema: public; Owner: pzoli
--

COPY public.accessibletype (id, typename) FROM stdin;
\.
COPY public.accessibletype (id, typename) FROM '$$PATH$$/2349.dat';

--
-- Name: accessibletype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pzoli
--

SELECT pg_catalog.setval('public.accessibletype_id_seq', 1, false);


--
-- Name: accessibletype accessibletype_pkey; Type: CONSTRAINT; Schema: public; Owner: pzoli
--

ALTER TABLE ONLY public.accessibletype
    ADD CONSTRAINT accessibletype_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

